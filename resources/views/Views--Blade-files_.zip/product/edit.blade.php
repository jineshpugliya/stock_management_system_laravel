@extends('layouts.main')
@section('content')

    <form method="post" action="/product/{{Crypt::encrypt($data->id)}}" enctype="multipart/form-data">

        @method('put')
        @csrf
        <div class="form-group" >
            <label for="name">Category Name </label>
        <input type="text" name="name" value="{{$data->name}}" class="form-control @error('name') border border-danger @enderror " id="name" placeholder="Enter Category ka New name ghalo">
        </div>
        <div class="form-group">
        <label for="description">Category Desc</label>
        <input type="text" name="description" value="{{$data->description}}" class="form-control @error('description') border border-danger @enderror " id="description" placeholder="Enter Category ka Description ">
        </div>
    </div>
    <div class="form-group">
        <label for="category">{{__('Category')}}</label>
        <select type="text" name="category_id" class="form-control @error('category_id') border border-danger @enderror " id="category" placeholder="Category roo Description Ghal ">
        <option value="{{$data->category_id}}">{{$data->category->name??''}}</option>
            @foreach($catdata as $cd)
            <option value="{{$cd->id}}">{{ucfirst($cd->name)}}</option>
        @endforeach
        </select>




    </div>
    <div class="form-group">
        <label for="subcategory">{{__('SubCategory')}}</label>
        <select type="text" name="subcategory_id" class="form-control @error('subcategory_id') border border-danger @enderror " id="subcategory" placeholder="Enter the the name of subcategiory ">

            <option value="{{$data->subcategory_id}}">{{$data->subcategory->name??''}}</option>

            @foreach($subcatdata as $sc)
                <option value="{{$sc->id}}">{{ucfirst($sc->name)}}</option>
            @endforeach
        </select>
        @error('subcategory_id')
            <small class="form-text text-danger">Please Select SubCategory</small>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
</form>
        {{-- <div class="form-group">
            <label for="exampleInputpro_category">Category</label>
            <input type="text" name="cat" value="{{$catdata->category}}"class="form-control @error('cat') border border-danger @enderror " id="exampleInputpro_category" placeholder="Category roo Category Ghal ">
            </div>

        <div class="form-group">
            <label for="media">Media</label>
            <input type="file" name="media" class="form-control @error('media') border border-danger @enderror " placeholder="Media" >
            </div>
            <img src={{Storage::url('public/media/'.$catdata->media)}} alt ="" height="200px" width="200px"> --}}
            {{-- <div class="form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Kaam puro ho gayo kya??</label>
        </div> --}}



@endsection
